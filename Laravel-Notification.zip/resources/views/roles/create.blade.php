@extends('layouts.app')

@section('content')
	<div class="container">
		<h2>Create Role</h2>
		<form action="{{ route('roles.store') }}"  method="POST" >
			@csrf 
			<input type="text" name="name" class="form-control" placeholder="Name"></br>
			<textarea name="description" class="form-control" rows="5" placeholder="Description"></textarea></br>
			<input type="submit" value="Submit" class="btn btn-primary">
			<a href="{{ route('roles.index') }}" class="btn btn-info">Back</a>
		</form>
	</div>
@endsection