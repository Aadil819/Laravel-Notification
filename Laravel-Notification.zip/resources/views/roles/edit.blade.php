@extends('layouts.app')

@section('content')
	<div class="container">
		<h2>Create Student</h2>
		<form action="{{ route('roles.update', $role->id) }}"  method="POST" >
			@csrf @method('PUT')
			<input type="text" name="name" class="form-control" placeholder="Name" required="" value="{{ $role->name }}"></br>
			<input type="text" name="description" class="form-control" placeholder="Email" required="" value="{{ $role->description }}"></br>
			
			<input type="submit" value="Update" class="btn btn-primary">
			<a href="{{ route('roles.index') }}" class="btn btn-info">Back</a>
		</form>
	</div>
@endsection