@extends('layouts.app')

@section('content')
<div class="container">
	<h2>Roles List</h2>
	 	<a href="{{ route('roles.create') }}" class="btn btn-info">Add Role</a>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Description</th>
				<th colspan="2" class="text-center" style="width:15%">Action</th>
			</tr>
		</thead>

		<tbody>
		@if($roles)
		@foreach($roles as $role )
			<tr>
				<td>{{ $role->id }}</td>
				<td>{{ $role->name }}</td>
				<td>{{ $role->description }}</td>
				<td><a href="{{ route('roles.edit', $role->id) }}" class="btn btn-primary btn-md">Edit </a> 
				</td>
				<td>
				<form method="POST" action="{{ route('roles.destroy',$role->id) }}" role="form">@csrf @method('DELETE')
                	<input type="submit" class="btn btn-danger btn-md" value="Delete">
                </form>
            </td>
			</tr>
		@endforeach
		@else
			<tr>
				<td colspan="4">No record found</td>
			</tr>
		@endif
		</tbody>
	</table>
</div>
@endsection