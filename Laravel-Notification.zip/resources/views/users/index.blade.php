@extends('layouts.app')

@section('content')
<div class="container">
	<h2>Users List</h2>
	@can('create-user')
	 	<a href="{{ route('users.create') }}" class="btn btn-info">Add New</a></br></br>
	@endcan
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Id</th>
				<th>Photo</th>
				<th>Name</th>
				<th>Email</th>
				<th>Phone</th>
				<th>User Type</th>
				@can('edit-user')
					<th colspan="2" class="text-center" style="width:15%">Action</th>
				@endcan 
			</tr>
		</thead>

		<tbody>
		@if($users)
		@foreach($users as $user )
			<tr>
				<td>{{ $user->id }}</td>
				<td>
					<img src="{{ url($user->photo) }}">
				</td>
				<td>{{ $user->name }}</td>
				<td>{{ $user->email }}</td>
				<td>{{ $user->phone }}</td>
				<td>{{ $user->user_type }}</td>
				@can('edit-user')
					<td><a href="{{ route('users.edit', $user->id) }}" class="btn btn-primary btn-md">Edit </a> 
				@endcan
				</td>
				@can('delete-user')
					<td>
						<form method="POST" action="{{ route('users.destroy',$user->id) }}" role="form">@csrf @method('DELETE')
		                	<input type="submit" class="btn btn-danger btn-md" value="Delete">
		                </form>
	            	</td>
				@endcan

			</tr>
		@endforeach
		@else
			<tr>
				<td colspan="4">No record found</td>
			</tr>
		@endif
		</tbody>
	</table>
</div>
@endsection