@extends('layouts.app')

@section('content')
	<div class="container">
		<h2>Edit User</h2>
		<form action="{{ route('users.update', $user->id) }}"  method="POST" >
			@csrf @method('PUT')
			<input type="text" name="name" class="form-control" placeholder="Name" required="" value="{{ $user->name }}"></br>
			<input type="email" name="email" class="form-control" placeholder="Email" required="" value="{{ $user->email }}"></br>
			<input type="text" name="phone" class="form-control" placeholder="Phone" required="" value="{{ $user->phone }}"></br>
			
			<input type="submit" value="Update" class="btn btn-primary">
			<a href="{{ route('users.index') }}" class="btn btn-info">Back</a>
		</form>
	</div>
@endsection