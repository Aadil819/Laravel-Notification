@extends('layouts.app')

@section('content')
	<div class="container">
		<h2>Create User</h2>
		<form action="{{ route('users.store') }}"  method="POST" enctype="multipart/form-data">
			@csrf 
			<input type="text" name="name" class="form-control" placeholder="Name" required=""></br>
			<input type="email" name="email" class="form-control" placeholder="Email" required=""></br>
			<input type="text" name="phone" class="form-control" placeholder="Phone" required=""></br>
			<input type="password" name="password" class="form-control" placeholder="Password" required=""></br>
			
			<input type="file" name="photo" class="form-control" required=""></br>
			
			<input type="submit" value="Submit" class="btn btn-primary">
			<a href="{{ route('users.index') }}" class="btn btn-info">Back</a>
		</form>
	</div>
@endsection