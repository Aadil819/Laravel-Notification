<?php

namespace App\Http\Controllers;

use App\User;
use App\Role;
use App\Notifications\RegisterationNotification;
use Illuminate\Http\Request;
use App\Http\Controllers\Auth;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if($this->authorize('view-users')){
            $users = User::all();
            return view('users.index', compact('users'));
        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if($this->authorize('create-user')){
            return view('users.create');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if($this->authorize('create-user')){

        $image = $request->file('photo');
        $path = $image->store('images', 'public');
        $password = $request->get('password');

        $user =  User::create([
            'name' => $request->name,
            'email'=> $request->email,
            'phone'=> $request->phone,
            'photo'=> $path,
            'user_type' => 'Student',
            'password'=> bcrypt($password)
        ]);


        // send Email notification
        $user->notify(new RegisterationNotification($user));
        

        //send SMS notification
        $basic  = new \Nexmo\Client\Credentials\Basic('bf3ad7bc', 'IKGOw01RcetAPMIA');
        $client = new \Nexmo\Client($basic);

        $message = $client->message()->send([
            // 'to' => $request->phone,
            'to'   => '923026775819',
            'from' => 'Laravel',
            'text' => 'Hello from Laravel'
        ]);

        return redirect()->route('users.index');
    }
    }


    public function show(User $user)
    {
        if($this->authorize('view-user')){
            return view('home', compact('user'));
        }
    }

    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\User  $User
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        if($this->authorize('edit-user')){
            return view('users.edit', compact('user'));
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\User  $User
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        if($this->authorize('edit-user')){

            if($user){
                $user->update($request->all());
            }

            return redirect()->route('users.index');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\User  $User
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        if($this->authorize('delete-user')){

            if($user){
                $user->delete($user);
            }
            return redirect()->route('users.index');
        }
    }
}
