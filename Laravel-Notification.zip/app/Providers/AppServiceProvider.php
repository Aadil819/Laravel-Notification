<?php

namespace App\Providers;

use App\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        Gate::define('create-user', function ($user) {
            return $user->user_type == 'Admin' ;
        });

        Gate::define('edit-user', function ($user) {
            return $user->user_type == 'Admin' ;
        });

        Gate::define('delete-user', function ($user) {
            return $user->user_type == 'Admin' ;
        });

        Gate::define('view-users', function ($user) {
            return $user->user_type == 'Admin' ;
        });

        Gate::define('view-user', function ($user) {
            return $user->user_type == 'Student' ;
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
