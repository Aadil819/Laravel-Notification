<?php $__env->startSection('content'); ?>
	<div class="container">
	<form action="<?php echo e(route('posts.save')); ?>" method="POST" class="form" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>
		<input type="text" name="title" placeholder="Title" class="form-control">
		<textarea name="content" placeholder="Description" rows="5" class="form-control"></textarea>
		<input type="file" name="image" class="form-control">
		<input type="submit" value="Submit" class="btn btn-primary "  >

	</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>