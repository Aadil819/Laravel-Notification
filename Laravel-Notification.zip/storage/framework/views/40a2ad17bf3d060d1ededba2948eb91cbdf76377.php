<!DOCTYPE html>
<html>
<head>
	<title>Laravel</title>
</head>
<body>

	<h2>Welcome,<?php echo e($user->name); ?></h2>

	<p>You have been successfully registered</p>

	<p><b>Regards:</b></br>
		Laravel Developers Team
	</p>

</body>
</html>