<?php $__env->startSection('content'); ?>
<div class="container">
	<h2>Roles List</h2>
	 	<a href="<?php echo e(route('roles.create')); ?>" class="btn btn-info">Add Role</a>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Description</th>
				<th colspan="2" class="text-center" style="width:15%">Action</th>
			</tr>
		</thead>

		<tbody>
		<?php if($roles): ?>
		<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($role->id); ?></td>
				<td><?php echo e($role->name); ?></td>
				<td><?php echo e($role->description); ?></td>
				<td><a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="btn btn-primary btn-md">Edit </a> 
				</td>
				<td>
				<form method="POST" action="<?php echo e(route('roles.destroy',$role->id)); ?>" role="form"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                	<input type="submit" class="btn btn-danger btn-md" value="Delete">
                </form>
            </td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php else: ?>
			<tr>
				<td colspan="4">No record found</td>
			</tr>
		<?php endif; ?>
		</tbody>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>