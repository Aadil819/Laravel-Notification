<?php $__env->startSection('content'); ?>
<div class="container">
	<h2>Users List</h2>
	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-user')): ?>
	 	<a href="<?php echo e(route('users.create')); ?>" class="btn btn-info">Add New</a></br></br>
	<?php endif; ?>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>Id</th>
				<th>Photo</th>
				<th>Name</th>
				<th>Email</th>
				<th>Phone</th>
				<th>User Type</th>
				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-user')): ?>
					<th colspan="2" class="text-center" style="width:15%">Action</th>
				<?php endif; ?> 
			</tr>
		</thead>

		<tbody>
		<?php if($users): ?>
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($user->id); ?></td>
				<td>
					<img src="<?php echo e(url($user->photo)); ?>">
				</td>
				<td><?php echo e($user->name); ?></td>
				<td><?php echo e($user->email); ?></td>
				<td><?php echo e($user->phone); ?></td>
				<td><?php echo e($user->user_type); ?></td>
				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-user')): ?>
					<td><a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary btn-md">Edit </a> 
				<?php endif; ?>
				</td>
				<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-user')): ?>
					<td>
						<form method="POST" action="<?php echo e(route('users.destroy',$user->id)); ?>" role="form"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
		                	<input type="submit" class="btn btn-danger btn-md" value="Delete">
		                </form>
	            	</td>
				<?php endif; ?>

			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php else: ?>
			<tr>
				<td colspan="4">No record found</td>
			</tr>
		<?php endif; ?>
		</tbody>
	</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>