<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <h1><?php echo e($posts->count()); ?> posts</h1>
                <a href="<?php echo e(route('posts.create')); ?>" role="button" class="btn btn-info">Add Role</a>
                <div class="p-lg-2"></div>
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th style="width: 10%;">Id</th>
                        <th style="width: 20%;">Image</th>
                        <th style="width: 50%;">Name</th>
                        <th style="width: 10%;">Edit</th>
                        <th style="width: 10%;">Delete</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($post->id); ?></td>
                            
                                <img src="<?php echo e(url($post->url)); ?>"></td>
                            <td><?php echo e($post->title); ?></td>

                            <td>
                                <a href="<?php echo e(route('posts.edit',$post->id)); ?>" role="button" class="btn btn-info">Edit</a>
                            </td>
                            <td>
                                <form method="POST" action="<?php echo e(route('posts.delete',$post->id)); ?>" role="form">
                                    <?php echo csrf_field(); ?>

                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="btn btn-danger">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>